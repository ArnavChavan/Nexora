# NEXORA (Stage 4, no AI)

Liquid Glass Android browser on the system WebView. Gradle 8.7, JDK 17, compileSdk 34, minSdk 24.

Stage 3 features: tabs, bookmarks, history, find in page, downloads, desktop/dark modes, NEXORA Shield
(ad/tracker + pop-up blocking, HTTP warnings, SSL errors blocked, privacy dashboard).

Stage 4 additions
- Private tabs (separate profile, no history, screenshots blocked, wiped when closed)
- Passwords and autofill through Android's autofill service (Menu > Passwords & autofill)
- Backup file: export/import bookmarks, history and settings
- QR scanner (Google Play services code scanner)
- Picture-in-picture: play a video full screen, then press Home
- Offline reading: save a page, open it from Menu > Offline pages
- Full-page screenshot (saved to Pictures/NEXORA)

Tab switcher: full-screen cards with page previews, staggered pop-in, shrink-away close, zoom-in select.
Find bar: springs in from the top, slides away, wiggles when nothing matches.
