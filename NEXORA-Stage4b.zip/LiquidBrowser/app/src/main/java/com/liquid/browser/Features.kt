package com.liquid.browser

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewFeature
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import java.io.File

private fun MainActivity.say(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

// ------------------------------------------------------------------ private (incognito) tabs

/** Deletes the separate private profile (cookies, storage, cache) when no private tab is open. */
fun MainActivity.wipeIncognito() {
    if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) return
    try {
        ProfileStore.getInstance().deleteProfile("incognito")
    } catch (_: Exception) {
        // Profile still in use or never created: nothing to delete.
    }
}

// ------------------------------------------------------------------ QR scanner

fun MainActivity.scanQr() {
    try {
        val options = GmsBarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
            .build()
        GmsBarcodeScanning.getClient(this, options).startScan()
            .addOnSuccessListener { barcode ->
                val raw = barcode.rawValue
                if (!raw.isNullOrBlank()) showQrResult(raw)
            }
            .addOnFailureListener {
                say("QR scanner is not available on this device (needs Google Play services)")
            }
    } catch (e: Exception) {
        say("QR scanner is not available on this device")
    }
}

private fun MainActivity.showQrResult(raw: String) {
    val isLink = raw.startsWith("http://") || raw.startsWith("https://")
    val items = mutableListOf<SheetItem>()
    items.add(
        SheetItem(if (isLink) "Open link" else "Search for this text", raw) {
            hideSheet(); go(raw)
        }
    )
    items.add(SheetItem("Copy") {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("qr", raw))
        hideSheet(); say("Copied")
    })
    showSheet("QR code", items)
}

// ------------------------------------------------------------------ offline reading

fun MainActivity.offlineDir(): File = File(filesDir, "offline").apply { mkdirs() }

fun MainActivity.saveOffline() {
    val wv = curWeb ?: return
    val url = wv.url.orEmpty()
    if (curTab?.incognito == true) { say("Not available in private tabs"); return }
    if (url.isEmpty() || url == "about:blank" || url.startsWith("file:") || url.startsWith("data:")) {
        say("Open a web page first"); return
    }
    val title = curTab?.title.orEmpty().ifBlank { url }
    val file = File(offlineDir(), "${System.currentTimeMillis()}.mht")
    say("Saving page…")
    wv.saveWebArchive(file.absolutePath, false) { path ->
        if (path != null) {
            store.addOffline(OfflineItem(title, url, file.absolutePath))
            say("Saved for offline reading")
        } else {
            say("Could not save this page")
        }
    }
}

fun MainActivity.showOfflinePages() {
    val list = store.offlinePages()
    val items = list.map { p ->
        SheetItem(
            title = p.title,
            sub = Utils.prettyUrl(p.origin),
            onRemove = {
                File(p.file).delete()
                store.removeOffline(p.file)
                showOfflinePages()
            },
            onClick = { hideSheet(); go("file://" + p.file) }
        )
    }
    showSheet(if (items.isEmpty()) "No offline pages yet" else "Offline pages", items)
}

// ------------------------------------------------------------------ passwords (via Android autofill)

fun MainActivity.openAutofillSettings() {
    if (Build.VERSION.SDK_INT < 26) {
        say("Autofill needs Android 8 or newer"); return
    }
    try {
        startActivity(
            Intent(Settings.ACTION_REQUEST_SET_AUTOFILL_SERVICE)
                .setData(Uri.parse("package:$packageName"))
        )
    } catch (_: Exception) {
        try {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        } catch (_: Exception) {
            say("Open Android Settings and search for \"Autofill service\"")
        }
    }
}

// ------------------------------------------------------------------ full-page screenshot

/**
 * Scrolls through the page one screen at a time and stitches the screens together.
 * Uses 16-bit colour and a size cap (about 10 million pixels) so low-end phones do not run out of memory.
 */
fun MainActivity.captureFullPage() {
    val wv = curWeb ?: return
    val w = wv.width
    val vh = wv.height
    if (w <= 0 || vh <= 0) return

    @Suppress("DEPRECATION")
    val fullH = (wv.contentHeight * wv.scale).toInt()
    val totalH = fullH.coerceIn(vh, maxOf(vh, 10_000_000 / w))

    val bitmaps = try {
        Pair(
            Bitmap.createBitmap(w, totalH, Bitmap.Config.RGB_565),
            Bitmap.createBitmap(w, vh, Bitmap.Config.RGB_565)
        )
    } catch (e: OutOfMemoryError) {
        null
    }
    if (bitmaps == null) { say("This page is too large for this device's memory"); return }
    val full = bitmaps.first
    val slice = bitmaps.second
    val fullCanvas = Canvas(full)
    val sliceCanvas = Canvas(slice)
    fullCanvas.drawColor(Color.WHITE)

    val startY = wv.scrollY
    val handler = Handler(Looper.getMainLooper())
    say("Capturing the page… please do not touch the screen")

    fun done() {
        wv.scrollTo(0, startY)
        slice.recycle()
        saveScreenshot(full)
    }

    fun step(y: Int) {
        wv.scrollTo(0, y)
        handler.postDelayed({
            val actual = wv.scrollY
            sliceCanvas.drawColor(Color.WHITE)
            wv.draw(sliceCanvas)
            fullCanvas.drawBitmap(slice, 0f, actual.toFloat(), null)
            val next = y + vh
            if (actual < y || next >= totalH) done() else step(next)
        }, 250)
    }

    step(0)
}

@Suppress("DEPRECATION")
private fun MainActivity.saveScreenshot(bmp: Bitmap) {
    val job: () -> Unit = {
        try {
            val name = "NEXORA_${System.currentTimeMillis()}.jpg"
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/NEXORA")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("insert failed")
                contentResolver.openOutputStream(uri)?.use { out ->
                    bmp.compress(Bitmap.CompressFormat.JPEG, 90, out)
                }
            } else {
                MediaStore.Images.Media.insertImage(contentResolver, bmp, name, "")
                    ?: throw IllegalStateException("insert failed")
            }
            say("Screenshot saved in Pictures")
        } catch (e: Exception) {
            say("Could not save the screenshot")
        } finally {
            bmp.recycle()
        }
    }
    withStorage(job)
}
