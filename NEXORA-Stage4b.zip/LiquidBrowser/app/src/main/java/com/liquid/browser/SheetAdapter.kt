package com.liquid.browser

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageButton
import android.widget.TextView

class SheetItem(
    val title: String,
    val sub: String = "",
    val highlight: Boolean = false,
    val onRemove: (() -> Unit)? = null,
    val onClick: () -> Unit = {}
)

/** Simple list adapter used by every bottom sheet (tabs, menu, bookmarks, history). */
class SheetAdapter(private val ctx: Context) : BaseAdapter() {
    var items: List<SheetItem> = emptyList()
        set(v) { field = v; notifyDataSetChanged() }

    override fun getCount() = items.size
    override fun getItem(position: Int) = items[position]
    override fun getItemId(position: Int) = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val v = convertView ?: LayoutInflater.from(ctx).inflate(R.layout.item_row, parent, false)
        val item = items[position]
        val title = v.findViewById<TextView>(R.id.rowTitle)
        val sub = v.findViewById<TextView>(R.id.rowSub)
        val close = v.findViewById<ImageButton>(R.id.rowClose)

        title.text = item.title
        title.setTextColor(
            ctx.getColor(if (item.highlight) R.color.accent else R.color.text)
        )
        sub.text = item.sub
        sub.visibility = if (item.sub.isEmpty()) View.GONE else View.VISIBLE

        if (item.onRemove != null) {
            close.visibility = View.VISIBLE
            close.setOnClickListener { item.onRemove.invoke() }
        } else {
            close.visibility = View.GONE
        }
        v.setOnClickListener { item.onClick() }
        return v
    }
}
