package com.liquid.browser

/** Lightweight offline start page with a responsive Liquid Glass visual system. */
object StartPage {
    private val LINKS = listOf(
        "Google" to "https://www.google.com",
        "YouTube" to "https://m.youtube.com",
        "Wikipedia" to "https://www.wikipedia.org",
        "GitHub" to "https://github.com",
        "Reddit" to "https://www.reddit.com",
        "News" to "https://news.google.com",
        "Maps" to "https://maps.google.com",
        "Weather" to "https://weather.com"
    )

    fun html(): String {
        val tiles = LINKS.joinToString("") { (name, url) ->
            "<a class=\"tile\" href=\"$url\"><span class=\"tileIcon\">${name.first()}</span><span class=\"tileName\">$name</span><span class=\"tileArrow\">↗</span></a>"
        }
        return """
<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="color-scheme" content="light dark">
<style>
:root{color-scheme:light dark;--ink:#182238;--muted:#66738b;--line:rgba(255,255,255,.62);--glass:rgba(255,255,255,.56);--tile:rgba(255,255,255,.48);--accent:#5579f7;--bg1:#eaf1ff;--bg2:#f8edff;--shadow:0 18px 55px rgba(60,83,145,.13)}
@media(prefers-color-scheme:dark){:root{--ink:#f2f5ff;--muted:#aab5ce;--line:rgba(255,255,255,.12);--glass:rgba(26,34,57,.68);--tile:rgba(255,255,255,.055);--accent:#9bb2ff;--bg1:#11182b;--bg2:#211a35;--shadow:0 18px 55px rgba(0,0,0,.24)}}
*{box-sizing:border-box}html{min-height:100%;background:var(--bg1)}
body{margin:0;min-height:100vh;padding:44px 20px 170px;color:var(--ink);font-family:Inter,system-ui,-apple-system,Roboto,sans-serif;background:radial-gradient(ellipse at 10% 8%,rgba(106,151,255,.25),transparent 36%),radial-gradient(ellipse at 92% 22%,rgba(198,137,255,.23),transparent 34%),linear-gradient(145deg,var(--bg1),var(--bg2));overflow-x:hidden}
.wrap{max-width:520px;margin:auto}.top{display:flex;align-items:center;justify-content:space-between;margin-bottom:42px}.brand{display:flex;align-items:center;gap:12px}.logo{width:42px;height:42px;border-radius:15px;display:grid;place-items:center;color:white;font-size:22px;font-weight:800;background:linear-gradient(145deg,#70a2ff,#8768e9);box-shadow:0 9px 24px rgba(91,119,235,.3)}.brandName{font-size:16px;font-weight:750;letter-spacing:.2px}.brandSub{font-size:11px;color:var(--muted);margin-top:2px}.shield{font-size:11px;font-weight:650;color:var(--accent);padding:9px 12px;border:1px solid var(--line);border-radius:30px;background:var(--glass);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px)}
.hero{text-align:left;margin-bottom:28px}.eyebrow{font-size:11px;text-transform:uppercase;letter-spacing:2px;font-weight:750;color:var(--accent);margin-bottom:12px}.hero h1{font-size:34px;line-height:1.1;letter-spacing:-1.4px;margin:0 0 10px;font-weight:780}.hero p{font-size:14px;line-height:1.6;color:var(--muted);margin:0;max-width:330px}
.searchHint{display:flex;align-items:center;gap:10px;padding:16px 17px;margin:26px 0 32px;border:1px solid var(--line);border-radius:22px;background:var(--glass);box-shadow:var(--shadow);backdrop-filter:blur(22px);-webkit-backdrop-filter:blur(22px);color:var(--muted);font-size:13px}.searchIcon{font-size:18px;color:var(--accent)}
.sectionHead{display:flex;align-items:center;justify-content:space-between;margin:0 2px 14px}.sectionHead strong{font-size:14px}.sectionHead span{font-size:11px;color:var(--muted)}.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:11px}.tile{position:relative;min-height:104px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:9px;padding:13px 5px;text-decoration:none;color:var(--ink);border:1px solid var(--line);border-radius:21px;background:var(--tile);box-shadow:0 8px 24px rgba(50,70,120,.055);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);transition:transform .16s,background .16s}.tile:active{transform:scale(.95)}.tileIcon{width:43px;height:43px;border-radius:15px;display:grid;place-items:center;font-size:18px;font-weight:750;color:var(--accent);background:linear-gradient(145deg,rgba(119,158,255,.22),rgba(190,151,255,.18));border:1px solid var(--line)}.tileName{font-size:11px;font-weight:650}.tileArrow{position:absolute;right:10px;top:8px;font-size:10px;color:var(--muted);opacity:.7}
.bottomNote{display:flex;align-items:center;justify-content:center;gap:7px;margin-top:30px;color:var(--muted);font-size:11px}.dot{width:6px;height:6px;border-radius:50%;background:#54c99a;box-shadow:0 0 10px #54c99a}
@media(max-width:360px){.grid{grid-template-columns:repeat(3,minmax(0,1fr))}.hero h1{font-size:30px}}
</style></head><body><main class="wrap">
<header class="top"><div class="brand"><div class="logo">N</div><div><div class="brandName">NEXORA</div><div class="brandSub">A calmer way to explore</div></div></div><div class="shield">✦ &nbsp; Privacy first</div></header>
<section class="hero"><div class="eyebrow">Your space on the web</div><h1>Make room<br>for discovery.</h1><p>Search, explore and move between your favourite places with a lighter browsing experience.</p></section>
<div class="searchHint"><span class="searchIcon">⌕</span><span>Use the address bar below to search or enter a website</span></div>
<div class="sectionHead"><strong>Quick access</strong><span>Your everyday destinations</span></div>
<nav class="grid">$tiles</nav>
<div class="bottomNote"><span class="dot"></span><span>Privacy protection is managed in NEXORA Shield</span></div>
</main></body></html>
""".trimIndent()
    }

    fun privateHtml(): String = """
<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
background:#0b0d14;color:#e8ebf5;font-family:sans-serif;text-align:center;padding:24px;box-sizing:border-box}
h1{font-size:26px;margin:0 0 10px}p{color:#9aa4b5;font-size:14px;line-height:1.6;max-width:320px;margin:0 auto}
.b{display:inline-block;margin-bottom:18px;padding:8px 16px;border-radius:30px;background:#1c2230;color:#a98bff;font-size:12px;font-weight:700}
</style></head><body><div><div class="b">PRIVATE</div><h1>Private tab</h1>
<p>History, cookies and site data from private tabs are removed when you close all of them. Screenshots are blocked in private tabs.</p></div></body></html>
""".trimIndent()
}
