package com.liquid.browser

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Entry(val title: String, val url: String)

data class OfflineItem(val title: String, val origin: String, val file: String)

/** Tiny SharedPreferences-backed storage. No database = no extra RAM or APK size. */
class Store(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("liquid", Context.MODE_PRIVATE)

    var desktopMode: Boolean
        get() = sp.getBoolean("desktop", false)
        set(v) = sp.edit().putBoolean("desktop", v).apply()

    var blockAds: Boolean
        get() = sp.getBoolean("ads", true)
        set(v) = sp.edit().putBoolean("ads", v).apply()

    /** Data saver: blocks images, great for slow networks and low RAM. */
    var dataSaver: Boolean
        get() = sp.getBoolean("saver", false)
        set(v) = sp.edit().putBoolean("saver", v).apply()

    var forceDark: Boolean
        get() = sp.getBoolean("dark", false)
        set(v) = sp.edit().putBoolean("dark", v).apply()

    var searchEngine: Int
        get() = sp.getInt("engine", 0)
        set(v) = sp.edit().putInt("engine", v).apply()


    var blockPopups: Boolean
        get() = sp.getBoolean("block_popups", true)
        set(v) = sp.edit().putBoolean("block_popups", v).apply()

    var httpsWarnings: Boolean
        get() = sp.getBoolean("https_warnings", true)
        set(v) = sp.edit().putBoolean("https_warnings", v).apply()

    fun recordBlockedRequest() {
        sp.edit().putInt("blocked_requests", blockedRequests() + 1).apply()
    }
    fun blockedRequests() = sp.getInt("blocked_requests", 0)
    fun resetBlockedRequests() = sp.edit().putInt("blocked_requests", 0).apply()
    fun recordBlockedPopup() {
        sp.edit().putInt("blocked_popups", blockedPopups() + 1).apply()
    }
    fun blockedPopups() = sp.getInt("blocked_popups", 0)
    fun resetPrivacyStats() = sp.edit()
        .putInt("blocked_requests", 0).putInt("blocked_popups", 0).apply()

    // ---- lists ----
    private fun read(key: String): MutableList<Entry> {
        val out = mutableListOf<Entry>()
        try {
            val arr = JSONArray(sp.getString(key, "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Entry(o.optString("t"), o.optString("u")))
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun write(key: String, list: List<Entry>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("t", it.title).put("u", it.url)) }
        sp.edit().putString(key, arr.toString()).apply()
    }

    fun bookmarks() = read("bookmarks")
    fun history() = read("history")

    fun isBookmarked(url: String) = bookmarks().any { it.url == url }

    /** @return true if now bookmarked */
    fun toggleBookmark(title: String, url: String): Boolean {
        val list = bookmarks()
        val existing = list.indexOfFirst { it.url == url }
        return if (existing >= 0) {
            list.removeAt(existing); write("bookmarks", list); false
        } else {
            list.add(0, Entry(title.ifBlank { url }, url)); write("bookmarks", list); true
        }
    }

    fun removeBookmark(url: String) = write("bookmarks", bookmarks().filter { it.url != url })

    fun addHistory(title: String, url: String) {
        if (url.startsWith("about:") || url.startsWith("file:")) return
        val list = history()
        list.removeAll { it.url == url }
        list.add(0, Entry(title.ifBlank { url }, url))
        write("history", list.take(150)) // capped: keeps memory & disk tiny
    }

    fun removeHistory(url: String) = write("history", history().filter { it.url != url })
    fun clearHistory() = sp.edit().remove("history").apply()

    // ---- offline pages ----
    fun offlinePages(): MutableList<OfflineItem> {
        val out = mutableListOf<OfflineItem>()
        try {
            val arr = JSONArray(sp.getString("offline", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(OfflineItem(o.optString("t"), o.optString("o"), o.optString("f")))
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun writeOffline(list: List<OfflineItem>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("t", it.title).put("o", it.origin).put("f", it.file)) }
        sp.edit().putString("offline", arr.toString()).apply()
    }

    fun addOffline(item: OfflineItem) {
        val list = offlinePages()
        list.add(0, item)
        writeOffline(list)
    }

    fun removeOffline(file: String) = writeOffline(offlinePages().filter { it.file != file })

    // ---- backup (move your data between devices by saving the file anywhere you like) ----
    fun exportJson(): String {
        val o = JSONObject()
        o.put("app", "NEXORA")
        o.put("version", 1)
        val bm = JSONArray()
        bookmarks().forEach { bm.put(JSONObject().put("t", it.title).put("u", it.url)) }
        o.put("bookmarks", bm)
        val hi = JSONArray()
        history().forEach { hi.put(JSONObject().put("t", it.title).put("u", it.url)) }
        o.put("history", hi)
        o.put(
            "settings", JSONObject()
                .put("desktop", desktopMode).put("ads", blockAds).put("saver", dataSaver)
                .put("dark", forceDark).put("engine", searchEngine)
                .put("popups", blockPopups).put("https", httpsWarnings)
        )
        return o.toString(2)
    }

    /** Merges bookmarks and history, applies settings. @return false if the file is not a valid backup. */
    fun importJson(text: String): Boolean {
        return try {
            val o = JSONObject(text)
            if (o.optString("app") != "NEXORA") return false
            val bm = bookmarks()
            val seen = bm.map { it.url }.toMutableSet()
            o.optJSONArray("bookmarks")?.let { a ->
                for (i in 0 until a.length()) {
                    val e = a.getJSONObject(i)
                    val u = e.optString("u")
                    if (u.isNotEmpty() && seen.add(u)) bm.add(Entry(e.optString("t", u), u))
                }
            }
            write("bookmarks", bm)
            val hi = history()
            val seenH = hi.map { it.url }.toMutableSet()
            o.optJSONArray("history")?.let { a ->
                for (i in 0 until a.length()) {
                    val e = a.getJSONObject(i)
                    val u = e.optString("u")
                    if (u.isNotEmpty() && seenH.add(u)) hi.add(Entry(e.optString("t", u), u))
                }
            }
            write("history", hi.take(150))
            o.optJSONObject("settings")?.let { s ->
                if (s.has("desktop")) desktopMode = s.getBoolean("desktop")
                if (s.has("ads")) blockAds = s.getBoolean("ads")
                if (s.has("saver")) dataSaver = s.getBoolean("saver")
                if (s.has("dark")) forceDark = s.getBoolean("dark")
                if (s.has("engine")) searchEngine = s.getInt("engine")
                if (s.has("popups")) blockPopups = s.getBoolean("popups")
                if (s.has("https")) httpsWarnings = s.getBoolean("https")
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    // ---- session restore ----
    fun saveSession(urls: List<String>, active: Int) {
        sp.edit().putString("session", JSONArray(urls).toString()).putInt("active", active).apply()
    }

    fun loadSession(): Pair<List<String>, Int> {
        val urls = mutableListOf<String>()
        try {
            val arr = JSONArray(sp.getString("session", "[]"))
            for (i in 0 until arr.length()) urls.add(arr.getString(i))
        } catch (_: Exception) {
        }
        return urls to sp.getInt("active", 0)
    }
}
