package com.liquid.browser

import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.ViewTreeObserver
import android.view.animation.AccelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

// ------------------------------------------------------------------ thumbnails

private const val THUMB_WIDTH = 300   // small on purpose: low RAM use

/** Takes a small snapshot of a tab's page. Skipped for private tabs and tabs not on screen. */
fun MainActivity.captureThumb(t: Tab) {
    if (t.incognito) return
    val wv = t.webView ?: return
    if (wv.parent == null || wv.width <= 0 || wv.height <= 0) return
    try {
        val scale = minOf(1f, THUMB_WIDTH.toFloat() / wv.width)
        val w = maxOf(1, (wv.width * scale).toInt())
        val h = maxOf(1, (wv.height * scale).toInt())
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.RGB_565)
        val canvas = Canvas(bmp)
        canvas.drawColor(getColor(R.color.bg))
        canvas.scale(scale, scale)
        wv.draw(canvas)
        t.thumb = bmp
    } catch (e: Exception) {
        // keep the old thumbnail
    } catch (e: OutOfMemoryError) {
        t.thumb = null
    }
}

// ------------------------------------------------------------------ card grid

class TabGridAdapter(private val act: MainActivity) : BaseAdapter() {
    override fun getCount() = act.tabs.size
    override fun getItem(position: Int): Any = act.tabs[position]
    override fun getItemId(position: Int) = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val v = convertView ?: LayoutInflater.from(act).inflate(R.layout.item_tab, parent, false)
        val tab = act.tabs[position]

        // Views are recycled, so clear any leftover animation state first.
        v.animate().cancel()
        v.alpha = 1f
        v.scaleX = 1f
        v.scaleY = 1f
        v.translationX = 0f
        v.translationY = 0f

        val pad = act.dp(8)
        v.setBackgroundResource(
            if (position == act.current) R.drawable.card_bg_current else R.drawable.card_bg
        )
        v.setPadding(pad, pad, pad, pad)

        val host = Utils.hostOf(tab.url)
        v.findViewById<TextView>(R.id.tabTitle).text = when {
            tab.incognito -> "Private tab"
            tab.title.isNotBlank() -> tab.title
            host.isNotBlank() -> host
            else -> "New tab"
        }

        val frame = v.findViewById<View>(R.id.thumbFrame)
        frame.clipToOutline = true
        frame.outlineProvider = ViewOutlineProvider.BACKGROUND

        val img = v.findViewById<ImageView>(R.id.tabThumb)
        val ph = v.findViewById<TextView>(R.id.tabPlaceholder)
        val thumb = tab.thumb
        if (!tab.incognito && thumb != null && !thumb.isRecycled) {
            img.setImageBitmap(thumb)
            img.visibility = View.VISIBLE
            ph.visibility = View.GONE
        } else {
            img.setImageDrawable(null)
            img.visibility = View.GONE
            ph.visibility = View.VISIBLE
            ph.text = when {
                tab.incognito -> "Private"
                host.isNotBlank() -> host.first().uppercase()
                else -> "N"
            }
            ph.textSize = if (tab.incognito) 16f else 30f
        }

        v.setOnClickListener { act.pickTab(position, v) }
        v.findViewById<ImageButton>(R.id.tabClose).setOnClickListener { act.closeTabCard(position, v) }
        return v
    }
}

// ------------------------------------------------------------------ open / close

private fun MainActivity.overlay() = findViewById<FrameLayout>(R.id.tabOverlay)
private fun MainActivity.grid() = findViewById<GridView>(R.id.tabGrid)

fun MainActivity.isTabSwitcherOpen() = overlay().visibility == View.VISIBLE

private fun MainActivity.updateTabHeader() {
    findViewById<TextView>(R.id.tabHeader).text =
        if (tabs.size == 1) "1 tab" else "${tabs.size} tabs"
}

fun MainActivity.openTabSwitcher() {
    hideSheet()
    closeFind()
    urlField.clearFocus()
    hideKeyboard(urlField)
    tabs.getOrNull(current)?.let { captureThumb(it) }

    val overlay = overlay()
    val grid = grid()
    val adapter = (grid.adapter as? TabGridAdapter)
        ?: TabGridAdapter(this).also { grid.adapter = it }

    // Buttons (listeners are cheap to set again each time).
    val bar = findViewById<LinearLayout>(R.id.tabBar)
    val bNew = findViewById<TextView>(R.id.tabNew)
    val bPrivate = findViewById<TextView>(R.id.tabPrivate)
    val bDone = findViewById<TextView>(R.id.tabDone)
    val bAll = findViewById<TextView>(R.id.tabCloseAll)
    listOf(bNew, bPrivate, bDone, bAll).forEach { bounce(it) }
    bDone.setOnClickListener { closeTabSwitcher() }
    bNew.setOnClickListener { closeTabSwitcher(); newTab(); urlField.requestFocus() }
    bPrivate.setOnClickListener { closeTabSwitcher(); newTab(incognito = true); urlField.requestFocus() }
    bAll.setOnClickListener { closeAllTabs() }

    updateTabHeader()
    adapter.notifyDataSetChanged()
    grid.setSelection(current)

    overlay.animate().cancel()
    overlay.alpha = 0f
    overlay.visibility = View.VISIBLE
    overlay.animate().setStartDelay(0).alpha(1f).setDuration(200).start()

    bar.animate().cancel()
    bar.translationY = dp(110).toFloat()
    bar.animate().setStartDelay(120).translationY(0f).setDuration(420)
        .setInterpolator(OvershootInterpolator(1.1f)).start()

    // Cards pop in one after another once they have been laid out.
    grid.viewTreeObserver.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
        override fun onPreDraw(): Boolean {
            grid.viewTreeObserver.removeOnPreDrawListener(this)
            for (i in 0 until grid.childCount) {
                val v = grid.getChildAt(i)
                v.alpha = 0f
                v.scaleX = 0.82f
                v.scaleY = 0.82f
                v.translationY = dp(48).toFloat()
                v.animate().setStartDelay(i * 40L).alpha(1f).scaleX(1f).scaleY(1f)
                    .translationY(0f).setDuration(380)
                    .setInterpolator(OvershootInterpolator(1.05f)).start()
            }
            return true
        }
    })
}

fun MainActivity.closeTabSwitcher() {
    val overlay = overlay()
    if (overlay.visibility != View.VISIBLE) return
    overlay.animate().cancel()
    overlay.animate().setStartDelay(0).alpha(0f).setDuration(180).withEndAction {
        overlay.visibility = View.GONE
    }.start()
}

/** Tap a card: it grows slightly while the overlay fades, so it feels like zooming into the page. */
fun MainActivity.pickTab(index: Int, card: View) {
    card.animate().cancel()
    card.animate().setStartDelay(0).scaleX(1.12f).scaleY(1.12f).setDuration(200).start()
    switchTo(index)
    closeTabSwitcher()
}

/** Tap ✕ on a card: it shrinks and floats away, then the tab is closed. */
fun MainActivity.closeTabCard(index: Int, card: View) {
    card.animate().cancel()
    card.animate().setStartDelay(0).alpha(0f).scaleX(0.7f).scaleY(0.7f)
        .translationY(-dp(36).toFloat()).setDuration(210)
        .setInterpolator(AccelerateInterpolator()).withEndAction {
            closeTab(index)
            updateTabHeader()
            (grid().adapter as? TabGridAdapter)?.notifyDataSetChanged()
        }.start()
}

private fun MainActivity.closeAllTabs() {
    tabs.forEach { t ->
        t.webView?.let { w ->
            if (w.parent != null) webContainer.removeView(w)
            w.destroy()
        }
        t.webView = null
    }
    tabs.clear()
    wipeIncognito()
    current = 0
    newTab()
    updateTabHeader()
    (grid().adapter as? TabGridAdapter)?.notifyDataSetChanged()
    closeTabSwitcher()
}
