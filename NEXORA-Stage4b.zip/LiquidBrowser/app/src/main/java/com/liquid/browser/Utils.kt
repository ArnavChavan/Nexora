package com.liquid.browser

import android.net.Uri
import java.net.URLEncoder

object Utils {
    const val HOME = "about:blank"

    val ENGINES = listOf(
        "DuckDuckGo" to "https://duckduckgo.com/?q=",
        "Google" to "https://www.google.com/search?q=",
        "Bing" to "https://www.bing.com/search?q=",
        "Brave" to "https://search.brave.com/search?q="
    )

    // Desktop user agent (swap in when "Desktop site" is on)
    const val DESKTOP_UA =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Safari/537.36"

    /** Turns whatever the user typed into a loadable URL or a search URL. */
    fun resolve(input: String, engine: Int): String {
        val t = input.trim()
        if (t.isEmpty()) return HOME
        if (t.startsWith("http://") || t.startsWith("https://") ||
            t.startsWith("file://") || t.startsWith("about:")
        ) return t
        val looksLikeHost = !t.contains(' ') &&
            (t.contains('.') || t.startsWith("localhost"))
        if (looksLikeHost) return "https://$t"
        val base = ENGINES[engine.coerceIn(0, ENGINES.lastIndex)].second
        return base + URLEncoder.encode(t, "UTF-8")
    }

    fun hostOf(url: String?): String =
        try { Uri.parse(url ?: "").host?.removePrefix("www.") ?: "" } catch (_: Exception) { "" }

    fun prettyUrl(url: String?): String {
        if (url.isNullOrEmpty() || url == HOME) return ""
        if (url.startsWith("file://")) return "Offline page"
        return url.removePrefix("https://").removePrefix("http://").removePrefix("www.")
            .trimEnd('/')
    }
}
