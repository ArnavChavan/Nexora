package com.liquid.browser

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.view.View
import android.webkit.*
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream

@SuppressLint("SetJavaScriptEnabled")
fun MainActivity.applySettings(wv: WebView, incognito: Boolean = false) {
    val s = wv.settings
    s.javaScriptEnabled = true
    s.domStorageEnabled = true
    s.setSupportZoom(true)
    s.builtInZoomControls = true
    s.displayZoomControls = false
    s.useWideViewPort = true
    s.loadWithOverviewMode = true
    s.javaScriptCanOpenWindowsAutomatically = false
    s.setSupportMultipleWindows(false)
    s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
    s.mediaPlaybackRequiresUserGesture = true      // no autoplay = less data, less CPU
    s.allowFileAccess = true   // needed to open saved offline pages; file access from pages stays off
    s.allowFileAccessFromFileURLs = false
    s.allowUniversalAccessFromFileURLs = false
    s.cacheMode = if (incognito) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
    s.allowContentAccess = false
    s.blockNetworkImage = store.dataSaver           // Data saver: skip images
    s.userAgentString =
        if (store.desktopMode) Utils.DESKTOP_UA else WebSettings.getDefaultUserAgent(this)
    if (Build.VERSION.SDK_INT >= 26) s.safeBrowsingEnabled = true

    if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
        @Suppress("DEPRECATION")
        WebSettingsCompat.setForceDark(
            s,
            if (store.forceDark) WebSettingsCompat.FORCE_DARK_ON else WebSettingsCompat.FORCE_DARK_OFF
        )
    }
    if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
        WebSettingsCompat.setAlgorithmicDarkeningAllowed(s, store.forceDark)
    }
}

/** Re-apply settings to every live tab and reload the current one. */
fun MainActivity.applyPrefsToAll() {
    tabs.forEach { t -> t.webView?.let { applySettings(it, t.incognito) } }
    curWeb?.reload()
}

private fun MainActivity.tabOf(view: WebView?) = tabs.firstOrNull { it.webView === view }
private fun MainActivity.isCurrent(view: WebView?) = view != null && curWeb === view

@SuppressLint("ClickableViewAccessibility")
fun MainActivity.createWebView(incognito: Boolean = false): WebView {
    val wv = WebView(this)
    if (incognito && WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
        // Separate cookie/storage profile, so private tabs never share data with normal tabs.
        try { WebViewCompat.setProfile(wv, "incognito") } catch (_: Exception) {}
    }
    if (Build.VERSION.SDK_INT >= 26) {
        wv.importantForAutofill = if (incognito) View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS
        else View.IMPORTANT_FOR_AUTOFILL_YES
    }
    applySettings(wv, incognito)
    CookieManager.getInstance().setAcceptThirdPartyCookies(wv, false) // privacy
    wv.overScrollMode = View.OVER_SCROLL_NEVER

    wv.setDownloadListener { url, ua, disp, mime, _ -> download(url, ua, disp, mime) }

    wv.setFindListener { active, total, done ->
        findCount.text = if (total == 0) "No matches" else "${active + 1}/$total"
        if (done && total == 0 && findField.text.isNotEmpty()) shakeFind()
    }

    wv.setOnScrollChangeListener { _, _, y, _, oy ->
        val d = y - oy
        if (d > 10) hideBar() else if (d < -10 || y <= 0) showBar()
    }

    wv.setOnLongClickListener {
        val r = wv.hitTestResult
        val extra = r.extra
        when (r.type) {
            WebView.HitTestResult.SRC_ANCHOR_TYPE,
            WebView.HitTestResult.IMAGE_TYPE,
            WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                if (extra != null) {
                    showLinkMenu(extra, r.type != WebView.HitTestResult.SRC_ANCHOR_TYPE); true
                } else false
            }
            else -> false
        }
    }

    wv.webViewClient = object : WebViewClient() {
        override fun shouldInterceptRequest(
            view: WebView?, request: WebResourceRequest?
        ): WebResourceResponse? {
            if (store.blockAds && AdBlock.isBlocked(request?.url?.host)) {
                store.recordBlockedRequest()
                return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
            }
            return null
        }

        override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
            val u = req.url
            val scheme = u.scheme ?: return false
            if (scheme == "file") {
                // Only allow moving between saved offline pages; block web pages from opening local files.
                val ok = view.url?.startsWith("file://") == true &&
                    (u.path ?: "").startsWith(offlineDir().absolutePath)
                return !ok
            }
            if (scheme == "http" || scheme == "https" || scheme == "about" || scheme == "data") {
                return false
            }
            try {
                val i = if (scheme == "intent") {
                    Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME).apply {
                        addCategory(Intent.CATEGORY_BROWSABLE); component = null; selector = null
                    }
                } else Intent(Intent.ACTION_VIEW, u)
                startActivity(i)
            } catch (_: Exception) {
            }
            return true
        }

        override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
            tabOf(view)?.let { if (url != null && url != "about:blank") it.url = url }
            if (isCurrent(view)) {
                if (store.httpsWarnings && url?.startsWith("http://") == true) {
                    val host = Uri.parse(url).host.orEmpty()
                    if (host.isNotBlank() && host != lastHttpWarningHost) {
                        lastHttpWarningHost = host
                        android.widget.Toast.makeText(
                            this@createWebView, "Not secure: this site uses HTTP",
                            android.widget.Toast.LENGTH_LONG
                        ).show()
                    }
                } else if (url?.startsWith("https://") == true) {
                    lastHttpWarningHost = ""
                }
                updatePageProgress(5); updateUi()
            }
        }

        override fun onPageFinished(view: WebView, url: String?) {
            val t = tabOf(view) ?: return
            if (url != null) t.url = if (url.startsWith("data:")) t.url else url
            t.title = view.title.orEmpty()
            if (!t.incognito && url != null && url != "about:blank" && !url.startsWith("data:")) {
                store.addHistory(t.title, url)
            }
            if (isCurrent(view)) { swipe.isRefreshing = false; updatePageProgress(100); updateUi() }
        }

        override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
            if (isCurrent(view)) updateUi()
        }

        override fun onReceivedSslError(
            view: WebView, handler: SslErrorHandler, error: android.net.http.SslError
        ) {
            // Never bypass certificate errors: cancel the connection.
            handler.cancel()
            if (isCurrent(view)) {
                android.widget.Toast.makeText(
                    this@createWebView, "Secure connection failed. Page blocked.",
                    android.widget.Toast.LENGTH_LONG
                ).show()
            }
        }

        override fun onReceivedError(
            view: WebView, req: WebResourceRequest, err: WebResourceError
        ) {
            if (!req.isForMainFrame) return
            val html = """
                <html><head><meta name=viewport content="width=device-width,initial-scale=1">
                <style>body{font-family:sans-serif;text-align:center;padding:90px 24px;
                color:#888}h2{color:#4f7cff}a{display:inline-block;margin-top:20px;
                padding:12px 28px;border-radius:24px;background:#4f7cff;color:#fff;
                text-decoration:none}</style></head><body>
                <h2>Can't open this page</h2><p>${err.description}</p>
                <a href="${req.url}">Try again</a></body></html>
            """.trimIndent()
            view.loadDataWithBaseURL(req.url.toString(), html, "text/html", "utf-8", req.url.toString())
        }
    }

    wv.webChromeClient = object : WebChromeClient() {
        override fun onCreateWindow(
            view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?
        ): Boolean {
            if (store.blockPopups) store.recordBlockedPopup()
            return false
        }

        override fun onProgressChanged(view: WebView, p: Int) {
            if (isCurrent(view)) updatePageProgress(p)
        }

        override fun onReceivedTitle(view: WebView, title: String?) {
            tabOf(view)?.title = title.orEmpty()
        }

        override fun onShowCustomView(view: View, cb: CustomViewCallback) = showCustomView(view, cb)
        override fun onHideCustomView() = hideCustomView()

        override fun onShowFileChooser(
            webView: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams
        ): Boolean {
            fileCb?.onReceiveValue(null)
            fileCb = cb
            return try {
                launchFileChooser(params.createIntent()); true
            } catch (_: ActivityNotFoundException) {
                fileCb = null; false
            }
        }

        // Privacy by default: deny location / camera / mic requests.
        override fun onGeolocationPermissionsShowPrompt(
            origin: String?, callback: GeolocationPermissions.Callback?
        ) { callback?.invoke(origin, false, false) }

        override fun onPermissionRequest(request: PermissionRequest?) { request?.deny() }
    }
    return wv
}
